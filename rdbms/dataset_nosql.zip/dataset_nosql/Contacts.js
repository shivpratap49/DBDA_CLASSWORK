
db.contacts.insert({name: 'contact1', email: 'c1@test.com'})
db.contacts.insert({name: 'contact2', phone: '1236548'})
db.contacts.insert({name: 'contact3', email: 'c1@teset.com', phone: '1656454'})
db.contacts.insert({name: 'contact4', address: 'pune'})
